package t4a1;
import java.util.Scanner;
public class T4A1 {

    
    public static void main(String[] args) {

          ejercicio1 (); 
          ejercicio2 ();
          ejercicio3 ();
          ejercicio4 ();
    }
    public static void ejercicio1 (){
        Scanner obj=new Scanner (System.in);
        int numero,numero2 = 0;
        System.out.println("favor de escrbir un numero");
        numero=obj.nextInt();
        while (numero2<=numero){
            System.out.println(numero2);
            numero2 ++;
           
        }
              
        
    }
    public static void ejercicio2 (){
        Scanner obj=new Scanner (System.in);
        int piezas,piezas1=0;
        int tallas, tallaS=0,tallaM=0,tallaL=0,tallaXL=0;
           
        System.out.println("bienvenido, por favor ingrese la cantidad de piezas que desees confeccionar");
        piezas=obj.nextInt();
        
        while (piezas1<piezas){
            System.out.println("por faovr determine las tallas (de uno en uno y de acuerdo al numero que este indicado para elegir la talla) " + "\n1.talla S" + "\n1.talla M" + "\n1.talla L" + "\n1.talla XL");
            tallas=obj.nextInt();
            if (tallas>=4){
                System.out.println("por favor determine la talla correctamente ");
                piezas1++;
            }
            else {
                if (tallas ==1){
                tallaS++;
                piezas1++;
                
                }
                else if (tallas ==2){
                tallaM++;
                piezas1++;
                }
                else if (tallas ==3){
                tallaL++;
                piezas1++;
                    
                }
                else if (tallas ==4){
                 tallaM++;
                 piezas1++;
                }
            }
            
            
        }
        
        System.out.println("perfecto " + "\nlas talls de tipo S hay " + tallaS + "\nlas talls de tipo M hay " + tallaM + "\nlas tallas de tipo L hay " + tallaL
        + "\nlas talls de tipo M hay " + tallaM) ;
        
    }
    public static void ejercicio3 (){
        Scanner obj=new Scanner (System.in);
        
        int estudiantes,calificaciones=0,calificaciones1,calificacionesMayor=0,calificacionesMenor=0;
        
        System.out.println("ingrese por favor el numero de estudiantes que desee evaluar para las calificaciones");
        estudiantes =obj.nextInt();
        while (calificaciones< estudiantes){
            System.out.println("por favor ingrese la calificaciones del estudiante ");
            calificaciones1=obj.nextInt();
            
            
            if (calificaciones1>=70){
                calificacionesMayor ++;
                calificaciones ++;
            
                
            }
            
            else {
               calificacionesMenor ++;
               calificaciones ++ ;
            }
            
            
            
            
        }
        System.out.println("la cantidad de alumnos que sacaron mayor de 70 son " + calificacionesMayor + "\nla cantidad de alumnos que sacaron menores de 70 son " + calificacionesMenor );
    }
    
    public static void ejercicio4 (){
        Scanner obj=new Scanner (System.in);
        int multiplo=0,multiplo1=0, destinatario=0 ,resultado=0 ,derivadas=0;
        System.out.println("por favor escriba el multiplo que desea hacer");
        multiplo =obj.nextInt();
        
        System.out.println("por favor escrbir el numero que desee llegar ");
        destinatario =obj.nextInt();
        
        while (derivadas <=destinatario){
            
            
           multiplo1=multiplo;
           resultado =resultado+multiplo1;
           System.out.println(resultado);
            derivadas =derivadas + (multiplo);
            derivadas ++;
            
        }
        
    }
}
